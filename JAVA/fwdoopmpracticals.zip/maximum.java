/*
PROGRAM: MAXIMUM OF THREE NUMBERS 
NAME: SHERWIN PILLAI
CLASS: SE COMPS
BATCH: C 
ROLL NO.: 8358	
*/
class Maximum	// Class Maximum Declaration
{
	int a, b, c, result;
	Maximum(String[] args)	// Constructors
	{
		a = Integer.parseInt(args[0]);
		b = Integer.parseInt(args[1]);
		c = Integer.parseInt(args[2]);
	}
	void maximum()	// Funtion Maximum
	{
		result = (a>b ? ((a>c)?a:c):((b>c)?b:c));
	}
	void display()	Function Display
	{
		System.out.println("The Maximum number is "+result);
	}
}	
class Demo	// Class Demo Declaration
{
	public static void main(String[] args)	// Main Function
	{
		Maximum max = new Maximum(args);
		max.maximum();
		max.display();
	}
}
/*
OUTPUT:
1
2
3
The Maximum number is 3
*/